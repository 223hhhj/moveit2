- To compile the example type the following command:
 g++ main.cpp -I../include/ -lOptoForceAPI -o example

- To run the example type:
./example
