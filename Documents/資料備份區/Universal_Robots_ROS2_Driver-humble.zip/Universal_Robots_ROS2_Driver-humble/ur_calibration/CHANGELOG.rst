^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package ur_calibration
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

2.2.11 (2024-04-08)
-------------------

2.2.10 (2024-01-03)
-------------------

2.2.9 (2023-09-22)
------------------

2.2.8 (2023-06-26)
------------------

2.2.7 (2023-06-02)
------------------

2.2.6 (2022-11-28)
------------------

2.2.5 (2022-11-19)
------------------
* Fixes launchfile references (`#490 <https://github.com/UniversalRobots/Universal_Robots_ROS2_Driver/issues/490>`_)
  The filename with the dual type ending was wrong.
* Contributors: Felix Exner

2.2.4 (2022-10-07)
------------------

2.2.3 (2022-07-27)
------------------

2.2.2 (2022-07-19)
------------------
* Made sure all past maintainers are listed as authors (`#429 <https://github.com/UniversalRobots/Universal_Robots_ROS2_Driver/issues/429>`_)
* Contributors: Felix Exner

2.2.1 (2022-06-27)
------------------

2.2.0 (2022-06-20)
------------------
* Updated package maintainers
* Update license to BSD-3-Clause (`#277 <https://github.com/UniversalRobots/Universal_Robots_ROS2_Driver/issues/277>`_)
* Add missing dependency on angles and update formatting for linters. (`#283 <https://github.com/UniversalRobots/Universal_Robots_ROS2_Driver/issues/283>`_)
* Calibration extraction package (`#186 <https://github.com/UniversalRobots/Universal_Robots_ROS2_Driver/issues/186>`_)
* Contributors: Denis Štogl, Felix Exner, livanov93
